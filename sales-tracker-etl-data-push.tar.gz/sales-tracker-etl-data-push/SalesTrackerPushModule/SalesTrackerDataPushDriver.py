import boto3
import botocore
import Constants
from SalesTrackerDataPush import SalesTrackerDataPush
import datetime

from awsManager import AwsManager
from awsMetrics import AWSMetrics
from configManager import ConfigManager


class SalesTrackerDataPushDriver:
    def __init__(self, configFilePath, inputFileBasePath, aws_access_key_id, aws_secret_access_key,
                 delimiter):
        # self.tenant_id = tenant_id
        self.configFilePath = configFilePath
        self.inputFileBasePath = inputFileBasePath
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.session = boto3.Session(
            aws_access_key_id=self.aws_access_key_id,
            aws_secret_access_key=self.aws_secret_access_key,
        )
        self.delimiter = delimiter
        self.configManager = ConfigManager(configFilePath, self.session)
        self.awsmetric = AWSMetrics("cloudwatch",self.session)
        # self.cloudwatch = self.awsmetric.client
        # self.cloudwatch = boto3.client('cloudwatch')

    def processAllObjects(self):

        print("base path ", self.inputFileBasePath)
        configJsonData = self.configManager.configJson

        commonProps = configJsonData['common_props']

        awsManger = AwsManager("stepfunctions", self.session)
        response = awsManger.getListOfExecutions(commonProps[Constants.KEY_CONNECTOR_ID],'RUNNING')
        print("response",response)
        execAraay=response['executions']
        if execAraay == []:
            print("ERRORRECORD given arn :"+commonProps[Constants.KEY_CONNECTOR_ID]+ " have no running execution ARN.")
            exit(0)
        execARN = execAraay[0]['executionArn']
        # execARN = commonProps[Constants.KEY_CONNECTOR_ID]
        print("execId arn ",execARN)
        # exit(0)
        # execARN="arn:aws:states:us-east-1:759023010504:stateMachine:sales-tracker-etl-salesforce-data-flow-ooma-dev-metric"

        path = self.inputFileBasePath.split("//")
        path = path[1].split('/')
        bucketName = path[0]
        key = '/'.join(path[1:])

        s3_resource = self.session.resource('s3')
        s3 = self.session.client('s3')
        bucket = s3_resource.Bucket(bucketName)
        print("bucket :", bucketName)
        objTypesList = []
        if Constants.KEY_SALE_OBJECT in configJsonData and configJsonData[Constants.KEY_SALE_OBJECT] != {}:
            saleObject = configJsonData[Constants.KEY_SALE_OBJECT]
            print(saleObject[Constants.KEY_TYPES])
            objTypes = saleObject[Constants.KEY_TYPES]
            saleObjectschema = saleObject[Constants.KEY_SCHEMA_MAPPING]
            objTypesList1 = objTypes.split(',')

        if Constants.KEY_ACTIVITY_OBJECT in configJsonData and configJsonData[Constants.KEY_ACTIVITY_OBJECT] != {}:
            activityObject = configJsonData[Constants.KEY_ACTIVITY_OBJECT]
            print(activityObject[Constants.KEY_TYPES])
            objTypes = activityObject[Constants.KEY_TYPES]
            activityObjectschema = activityObject[Constants.KEY_SCHEMA_MAPPING]
            objTypesList2 = objTypes.split(',')

        objTypesList = objTypesList1 + objTypesList2
        schema = saleObjectschema + activityObjectschema
        for i in objTypesList:
            inputFilePath = self.inputFileBasePath + i + Constants.KEY_INTER
            print("i", inputFilePath)
            flag = False
            for j in schema:
                if i == j[Constants.KEY_OBJECT_TYPE]:
                    # print("same :", i, j)
                    flag = True
                    break
            if flag == False:
                print("given====== " + i + " ======not in mapping list")
                continue
            schemaObject = j

            ts = int(datetime.datetime.now().timestamp())
            errorFilePath = self.inputFileBasePath + i + Constants.KEY_ERROR + i + "_error_" + str(ts) + ".json"
            stateFilePath= self.inputFileBasePath + i + Constants.KEY_STATE + i + "_state"+".json"
            print("error file path : ", errorFilePath)

            try:
                res = s3.list_objects_v2(Bucket=bucketName, Prefix=key + i)['Contents']
                print("given inputpath :" + inputFilePath + " present")
                res = s3.list_objects_v2(Bucket=bucketName, Prefix=key + i + Constants.KEY_INTER)['Contents']
                print("given inputpath :" + inputFilePath  + Constants.KEY_INTER + " present")
            except KeyError:
                print("given inputpath :" + inputFilePath +" or " + inputFilePath  + Constants.KEY_INTER +" not present")
                print(KeyError)
                continue

            try:
                stateres = s3.list_objects_v2(Bucket=bucketName, Prefix=key + i + Constants.KEY_STATE)['Contents']
                print(stateres)
                # stateid = -1
                data = self.configManager.ReadConfigJsonFromS3(stateFilePath)
                stateid = data["id"]

            except KeyError:
                stateid =0



            job1 = SalesTrackerDataPush(self.configFilePath, inputFilePath, self.session,
                                        self.delimiter, errorFilePath, commonProps, schemaObject,self.awsmetric,i.lower(),execARN,stateFilePath,stateid)
            job1.processSalesObjectData()

        # After all object execution successfully we delete the state folder

        for objectlist in objTypesList:
            s3_resource.Bucket(bucketName).objects.filter(Prefix=key + objectlist + Constants.KEY_STATE).delete()

