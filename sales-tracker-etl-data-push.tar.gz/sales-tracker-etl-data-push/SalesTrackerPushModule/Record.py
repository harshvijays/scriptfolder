import json
import pandas as pd

class Record:
    def __init__(self, inputPath, session, delimiter, stateid,errorFilePath,stateFilePath):
        self.inputPath = inputPath
        self.session = session
        self.delimiter = delimiter
        # self.errorFilePath = errorFilePath
        # self.stateFilePath=stateFilePath
        self.inputSchema = []
        self.dfFinal = self.readCSVInDF()
        self.num = stateid
        self.activityNum = 0
        print("n  : ", self.num)

    def readCSVInDF(self):

        path = self.inputPath.split("//")
        path = path[1].split('/')
        bucketName = path[0]
        key = '/'.join(path[1:])
        s3_resource = self.session.resource('s3')
        s3 = self.session.client('s3')
        bucket = s3_resource.Bucket(bucketName)
        df1 = ""
        res = s3.list_objects_v2(Bucket=bucketName, Prefix=key)['Contents']
        res2 = (sorted(res, key=lambda i: i['LastModified']))
        print("res2 : ", res2)
        for key in res2:
            file = key['Key']
            obj = bucket.Object(key=file)
            # get the object
            response = obj.get()
            print("file size : ", file, response['ContentLength'])
            if response['ContentLength'] == 0:
                print("Empty file :", file)
                continue
            # read the contents of the file and split it into a list of lines
            if self.delimiter == 't' or self.delimiter == 'tab':
                self.delimiter = '\t'
            if self.delimiter == ',' or self.delimiter == 'comma':
                self.delimiter = ','
            p1 = "s3://" + bucketName + "/" + file
            # print("p1",p1)
            if p1.endswith(".csv"):
                # print("p1 :", p1)
                df = pd.read_csv(p1, sep=self.delimiter, header=0)
                # print(df)
                if self.inputSchema == []:
                    self.inputSchema = list(df.columns)
                    # print(self.inputSchema)
                    df1 = pd.DataFrame(columns=self.inputSchema)

                df1 = df1.append(df, ignore_index=True)

        print("final df", df1)
        return df1

    def writeJsonToS3(self, object,filepath):
        # path = self.errorFilePath.split("//")
        path = filepath.split("//")
        path = path[1].split('/')
        bucketName = path[0]
        key = '/'.join(path[1:])

        s3_resource = self.session.resource('s3')
        s3object = s3_resource.Object(bucketName, key)
        s3object.put(
            Body=(bytes(json.dumps(object).encode('UTF-8')))
        )


    def nextRecord(self):
        n = len(self.dfFinal)
        print("n", n, "num ", self.num)
        if n <= self.num:
            print("Next Record not exists. Total no of records : " + str(n))
            return None
        s = self.dfFinal.loc[int(self.num), :]
        dict1 = {}
        for i in self.inputSchema:
            dict1[i] = s[i]
        self.num += 1
        return dict1

    def getTotalCount(self):
        return len(self.dfFinal)

    def getRecordCount(self):
        return self.num - 1