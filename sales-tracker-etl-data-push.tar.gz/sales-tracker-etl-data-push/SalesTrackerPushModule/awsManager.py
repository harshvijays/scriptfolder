# from dependency \
import boto3
import json
# from dependency.progress.bar import Bar


class AwsManager():

    ## This constructor needs service name either 'stepfunctions' or 'events' to initialize
    def __init__(self, servicename, session):
        self.client = session.client(servicename)

    ## This function creates stepfunction the type filed will take 'STANDARD'|'EXPRESS' as values.
    def createStateMachine(self, statemachinename, statedefinationdict, rolearn, typename, tenantname):
        response = self.client.create_state_machine(
            name=statemachinename,
            definition=json.dumps(statedefinationdict),
            roleArn=rolearn,
            type=typename,
            tags=[
                {
                    'key': 'tenant',
                    'value': tenantname
                }
            ])
        return response

    def getListOfStateMachines(self):
        response = self.client.list_state_machines(maxResults=123)
        return response

    def deleteSatteMachine(self, statemachinearn):
        response = self.client.delete_state_machine(stateMachineArn=statemachinearn)
        return response

    def updateSatetMachine(self, statemachinearn, statedefinationdict, rolearn):
        response = self.client.update_state_machine(
            stateMachineArn=statemachinearn,
            definition=json.dumps(statedefinationdict),
            roleArn=rolearn)
        return response

    def getListOfExecutions(self, statemachinearn, statusfilter):
        response = self.client.list_executions(
            stateMachineArn=statemachinearn,
            statusFilter=statusfilter,
            maxResults=123)
        return response

    # Status should be 'ENABLED'|'DISABLED'
    def createSchedule(self, rulename, scheduleexpression, statestatus, desc, tenantname):
        response = self.client.put_rule(
            Name=rulename,
            ScheduleExpression=scheduleexpression,
            State=statestatus,
            Description=desc,
            Tags=[
                {
                    'Key': 'tenant',
                    'Value': tenantname
                },
            ])
        return response

    def attacheSchedule(self, rulename, ruleid, targetarn, targetrolearn):
        response = self.client.put_targets(
            Rule=rulename,
            Targets=[
                {
                    'Id': ruleid,
                    'Arn': targetarn,
                    'RoleArn': targetrolearn
                }])
        return response

    def dittachSchedule(self, rulename):
        response = self.client.disable_rule(Name=rulename)
        return response

    def createTaskDef(self, taskname, taskrolearn, execrolearn, networkmode, containerdef, cpuno, memno, tenantname):
        response = self.client.register_task_definition(
            family=taskname,
            taskRoleArn=taskrolearn,
            executionRoleArn=execrolearn,
            # network mode can be 'bridge'|'host'|'awsvpc'|'none'
            networkMode=networkmode,
            containerDefinitions=containerdef,
            requiresCompatibilities=["EC2", "FARGATE"],
            cpu=cpuno,
            memory=memno,
            tags=[
                {
                    'key': 'tenant',
                    'value': tenantname
                }
            ])
        return response

    def createLogGroup(self, logGroupName, tenantname):
        response = self.client.create_log_group(
            logGroupName=logGroupName,
            tags={
                'tenant': tenantname
            }
        )
        return response

    def createBucket(self, bucketname):
        response = self.client.create_bucket(
            ACL='private',
            Bucket=bucketname)
        return response

    # def copyBucketToBucket(self, sourcebucket, destinationbucket):
    #
    #     s3_resource = boto3.resource('s3')
    #     # print("objects",self.client.list_objects(Bucket=sourcebucket))
    #     bar = Bar('Data Copy Progress', max=len(self.client.list_objects(Bucket=sourcebucket)['Contents']))
    #     for key in self.client.list_objects(Bucket=sourcebucket)['Contents']:
    #         files = key['Key']
    #         copy_source = {'Bucket': sourcebucket, 'Key': files}
    #         response = s3_resource.meta.client.copy(copy_source, destinationbucket, files)
    #         bar.next()
    #     # print(files)
    #     return response

    def copyFileToBucket(self, filepath, bucketname, key):
        s3 = boto3.resource('s3')
        s3.meta.client.upload_file(filepath, bucketname, key)

    # To get resources details thorugh its tags
    def getServiceArns(self, key, value):
        response = self.client.get_resources(
            TagFilters=[
                {
                    'Key': key,
                    'Values': [
                        value
                    ]
                },
            ]
        )
        return response

    def getStepFucntionDef(self, arn):
        response = self.client.describe_state_machine(
            stateMachineArn=arn)
        return response

    def getScheduleDetail(self, arn):
        # print("Event rule ARN is ",arn)
        response = self.client.list_rule_names_by_target(
            TargetArn=arn
        )
        for name in response.get("RuleNames"):
            response = self.client.describe_rule(
                Name=name
            )
        return response

    def downloads3file(self, s3, bucketname, filepath, localpath):
        try:
            s3.meta.client.download_file(bucketname, filepath, localpath)
            response = "Download Complete"
        except Exception as e:
            print(e)
            response = "Download Failed"
        return response

    # Read s3 data
    def read_file(self, bucket, filename):
        response = self.client.get_object(Bucket=bucket, Key=filename)
        content = response['Body']
        # jsonObject = json.loads(content.read())
        response = content.read()
        return response
