import json
import Constants

class ConfigManager:
    def __init__(self,inputConfigFilePath,session):
        self.session=session
        self.inputConfigFilePath=inputConfigFilePath
        self.configJson = self.ReadConfigJsonFromS3(self.inputConfigFilePath)

    def readS3ConfigFile(self):
        path = self.inputConfigFilePath.split("//")
        path = path[1].split('/')
        bucketName = path[0]
        key = '/'.join(path[1:])
        s3_resource = self.session.resource('s3')
        obj=s3_resource.Object(bucketName,key)
        response = obj.get()['Body'].read().decode('utf-8').splitlines()
        config = {}
        for i in response:
            s = i.split("=")
            if len(s) == 2:
                config[s[0]]=s[1]
        return config

    def ReadConfigJsonFromS3(self,filePath):
        # path = self.inputConfigFilePath.split("//")
        path = filePath.split("//")
        path = path[1].split('/')
        bucketName = path[0]
        key = '/'.join(path[1:])
        s3_resource = self.session.resource('s3')
        obj = s3_resource.Object(bucketName, key)
        response = obj.get()['Body'].read().decode('utf-8')
        json_content = json.loads(response)
        return json_content



    # def getMappingFieldColumnName(self):
    #     # self.readS3ConfigFile()
    #     return self.config
    #
    # def getCoreFieldColumnName(self,fieldName):
    #     return self.config[Constants.KEY_PREFIX+fieldName]
    #
    # def getTenentId(self):
    #     return self.config[Constants.KEY_TENANT_ID]
    #
    # def getConfigProperty(self,fieldname):
    #     return self.config[fieldname]
    #
    # def getCustomFieldColumnName(self,objectName,fieldname):
    #     return self.config[Constants.KEY_CUSTOM_PREFIX+objectName+fieldname]




