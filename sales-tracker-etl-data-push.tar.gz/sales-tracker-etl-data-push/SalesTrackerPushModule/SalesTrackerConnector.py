import json

import requests
import configparser
from datetime import datetime
import Constants
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry


class SalesTrackerConnector:
    def __init__(self, commonConf):
        # self.configManagerObject = configManagerObject
        self.config = commonConf
        self.errorlist = []
        self.retry_strategy = Retry(
            total=commonConf['totalRetry'],
            backoff_factor=commonConf['retryBackoffFactorInSec'],
            status_forcelist=[429, 503],
            method_whitelist=["GET", "POST", "PUT", "PATCH"]
        )
        self.adapter = HTTPAdapter(max_retries=self.retry_strategy)
        self.http = requests.Session()
        self.http.mount("http://", self.adapter)

    def getAuthenticationToken(self, authInputObj):
        link = self.config['tokenUrl']
        # "https://portal-dev.fpsinc.com/api/v1.1/auth/token"
        try:
            r = self.http.post(link, json=authInputObj)

        except Exception as e:
            print("Api call failed ERROR : ",e)
            return "Retry Failed"
        res = r.json()
        if r.status_code >= 200 and r.status_code <= 226:
            token = res["token"]
            print("Success : " + token)
            return token
        else:
            raise Exception("status code : " + str(r.status_code) +
                            " Exception : " + str(r.json()))

    def getSaleConfigId(self, tenantId, token):
        link = self.config[Constants.KEY_URL] + self.config[Constants.KEY_BASEPATH] + tenantId + self.config[
            Constants.KEY_CONFIG]
        headers = {'Authorization': "Bearer " + str(token)}
        try:
            r = self.http.get(link, headers=headers)
        except Exception as e:
            print("Api call failed ERROR : ",e)
            return "Retry Failed"
        res = r.json()

        if r.status_code >= 200 and r.status_code <= 226 and res[Constants.KEY_STATUS_API] == Constants.KEY_SUCCESS:
            data = res[Constants.KEY_DATA]
            result = data[Constants.KEY_RESULT]
            idList = []
            for i in result:
                if i[Constants.KEY_STATUS_API] == Constants.KEY_ACTIVE:
                    idList.append(i["id"])
                    print("SUCCESSRECORD : \t ", link)
                    return i["id"]

            if idList == []:
                print("ERRORRECORD : \t ", link, "\t", res)
                raise Exception(
                    "status code : " + str(r.status_code) + " Exception : " + str(r.json()))
        else:
            print("ERRORRECORD : \t ", link, "\t", res)
            raise Exception("status code : " + str(r.status_code) +
                            " Exception : " + str(r.json()))

        r.close()
        return []

    def getSales(self, tenantId, sale_id, token):
        print(tenantId, sale_id)
        link = self.config[Constants.KEY_URL] + self.config[Constants.KEY_BASEPATH] + tenantId + self.config[
            Constants.KEY_SALES] + "/" + sale_id
        curtime = datetime.now().strftime("%d-%b-%Y %H:%M:%S")
        headers = {'Authorization': "Bearer " + str(token)}
        try:
            r = self.http.get(link, headers=headers)
        except Exception as e:
            print("Api call failed ERROR : ",e)
            return "Retry Failed"
        res = r.json()
        print(r.status_code, res)
        if r.status_code >= 200 and r.status_code <= 226:
            if Constants.KEY_STATUS_API in res:
                if res[Constants.KEY_STATUS_API] == Constants.KEY_SUCCESS:
                    sale_id = res["id"]
            else:
                sale_id = None
            print("SUCCESSRECORD : \t ", link, sale_id)
            return sale_id
        else:

            if r.status_code == 400 or res['status'] == 400:
                sale_id = None
                return sale_id
            else:
                print("ERRORRECORD : HTTP: \t ", link, "\t", res)
                result = {}
                result['saleId'] = sale_id
                result['error_reason'] = res['errorMessage']
                result['link'] = "Get sales HTTP : " + link
                result['execution_timestamp'] = curtime
                self.errorlist.append(result)

    def postSaleObject(self, tenantId, saleTrackerObject, token):
        link = self.config[Constants.KEY_URL] + self.config[Constants.KEY_BASEPATH] + tenantId + self.config[
            Constants.KEY_SALES]
        stageid = saleTrackerObject['stageId']
        headers = {'Content-type': 'application/json',
                   'Authorization': "Bearer " + str(token)}
        curtime = datetime.now().strftime("%d-%b-%Y %H:%M:%S")
        try: 
            r = self.http.post(link, json=saleTrackerObject, headers=headers)
        except Exception as e:
            print("Api call failed ERROR : ",e)
            return "Retry Failed"
        res = r.json()
        if r.status_code >= 200 and r.status_code <= 226:
            if res[Constants.KEY_STATUS_API] == Constants.KEY_SUCCESS:
                # id = res['id']
                r.close()
                print("SUCCESSRECORD ", stageid, " \t ", link)
                return r.status_code
            else:
                print("ERRORRECORD_", stageid, " \t ", link,
                      "\t saleTrackerObject : ", saleTrackerObject, "\t", res)
                if "error" in res:
                    error = res['error']
                    saleTrackerObject['error_reason'] = error['message']
                    if 'actual_error' in error:
                        saleTrackerObject['actual_error'] = error['actualError']
                else:
                    saleTrackerObject['error_reason'] = res
                saleTrackerObject['execution_timestamp'] = curtime
                saleTrackerObject['link'] = "Post HTTP : " + link
                self.errorlist.append(saleTrackerObject)
                return r.json()
        else:
            print("ERRORRECORD_", stageid, " HTTP: \t ", link,
                  "\t saleTrackerObject : ", saleTrackerObject, "\t", res)
            if "error" in res:
                error = res['error']
                if 'message' in error:
                    saleTrackerObject['error_reason'] = error['message']
                else:
                    saleTrackerObject['error_reason'] = error
                if 'actual_error' in error:
                    saleTrackerObject['actual_error'] = error['actualError']
            saleTrackerObject['execution_timestamp'] = curtime
            saleTrackerObject['link'] = "Post HTTP : " + link
            self.errorlist.append(saleTrackerObject)
            return None

    def patchSaleObject(self, tenantId, saleTrackerObject, token, stageid):
        link = self.config[Constants.KEY_URL] + self.config[Constants.KEY_BASEPATH] + tenantId + self.config[
            Constants.KEY_SALES]
        print("link :", link)
        # stageid = saleTrackerObject['stageId']
        headers = {'Content-type': 'application/json',
                   'Authorization': "Bearer " + str(token)}
        curtime = datetime.now().strftime("%d-%b-%Y %H:%M:%S")
        try:
            r = self.http.patch(link, json=saleTrackerObject, headers=headers)
        except Exception as e:
            print("Api call failed ERROR : ",e)
            return "Retry Failed"

        res = r.json()
        print("res ", res)
        if r.status_code >= 200 and r.status_code <= 226:
            if res[Constants.KEY_STATUS_API] == Constants.KEY_SUCCESS:
                # id = res['id']
                r.close()
                print("SUCCESSRECORD ", stageid, " \t ", link)
                return r.status_code
            else:
                print("ERRORRECORD_", stageid, " \t ", link,
                      "\t saleTrackerObject : ", saleTrackerObject, "\t", res)
                if "error" in res:
                    error = res['error']
                    saleTrackerObject['error_reason'] = error['message']
                    if 'actual_error' in error:
                        saleTrackerObject['actual_error'] = error['actualError']
                else:
                    saleTrackerObject['error_reason'] = res
                saleTrackerObject['execution_timestamp'] = curtime
                saleTrackerObject['link'] = "Post HTTP : " + link
                self.errorlist.append(saleTrackerObject)
                return r.json()
        else:
            print("ERRORRECORD_", stageid, " HTTP: \t ", link,
                  "\t saleTrackerObject : ", saleTrackerObject, "\t", res)
            if "error" in res:
                error = res['error']
                if 'message' in error:
                    saleTrackerObject['error_reason'] = error['message']
                else:
                    saleTrackerObject['error_reason'] = error
                if 'actual_error' in error:
                    saleTrackerObject['actual_error'] = error['actualError']
            saleTrackerObject['execution_timestamp'] = curtime
            saleTrackerObject['link'] = "Post HTTP : " + link
            self.errorlist.append(saleTrackerObject)
            return None

    def putSaleObject(self, tenantId, Sale_id, saleTrackerObject, token):
        link = self.config[Constants.KEY_URL] + self.config[Constants.KEY_BASEPATH] + tenantId + self.config[
            Constants.KEY_SALES] + "/" + Sale_id
        stageid = saleTrackerObject['stageId']
        headers = {'Authorization': "Bearer " + str(token)}
        curtime = datetime.now().strftime("%d-%b-%Y %H:%M:%S")
        try:
            r = self.http.put(link, json=saleTrackerObject, headers=headers)
        except Exception as e:
            print("Api call failed ERROR : ",e)
            return "Retry Failed"
        res = r.json()
        if r.status_code >= 200 and r.status_code <= 226:
            if res[Constants.KEY_STATUS_API] == Constants.KEY_SUCCESS:
                print("SUCCESSRECORD ", stageid, " \t ", link)
                return res
            else:
                print("ERRORRECORD_", stageid, " \t ", link,
                      "\t saleTrackerObject : ", saleTrackerObject, "\t", res)
                saleTrackerObject['link'] = "Put HTTP : " + link
                if "error" in res:
                    error = res['error']
                    saleTrackerObject['error_reason'] = error['message']
                    if 'actual_error' in error:
                        saleTrackerObject['actual_error'] = error['actualError']
                else:
                    saleTrackerObject['error_reason'] = res
                saleTrackerObject['execution_timestamp'] = curtime
                self.errorlist.append(saleTrackerObject)
        else:
            print("ERRORRECORD_", stageid, " HTTP: \t ", link,
                  "\t saleTrackerObject : ", saleTrackerObject, "\t", res)
            saleTrackerObject['link'] = "Put HTTP : " + link
            # saleTrackerObject['error_reason'] = res['errorMessage']
            if "error" in res:
                error = res['error']
                if 'message' in error:
                    saleTrackerObject['error_reason'] = error['message']
                else:
                    saleTrackerObject['error_reason'] = error
                if 'actual_error' in error:
                    saleTrackerObject['actual_error'] = error['actualError']
            saleTrackerObject['execution_timestamp'] = curtime
            self.errorlist.append(saleTrackerObject)
            return r

    def postActivityObject(self, tenantId, Sale_id, saleTrackerObject, activityLinkEndPoint, token, saleConfigId):
        link = self.config[Constants.KEY_URL] + self.config[Constants.KEY_BASEPATH] + tenantId + saleConfigId + "/" + \
            self.config[
            Constants.KEY_SALES] + self.config[Constants.KEY_ACTIVITIES] + activityLinkEndPoint

        print(link)
        curtime = datetime.now().strftime("%d-%b-%Y %H:%M:%S")

        headers = {'Content-type': 'application/json',
                   'Authorization': "Bearer " + str(token)}
        try:
            r = self.http.post(link, json=saleTrackerObject, headers=headers)
        except Exception as e:
            print("Api call failed ERROR : ",e)
            return "Retry Failed"
        res = r.json()
        print("post :", res)
        if r.status_code >= 200 and r.status_code <= 226:
            if Constants.KEY_STATUS_API in res:
                if res[Constants.KEY_STATUS_API] == Constants.KEY_SUCCESS:
                    print("SUCCESSRECORD Activity \t ", link)
                    return res
            else:
                print("ERRORRECORD_Activity \t ", link,
                      "\t saleTrackerObject : ", saleTrackerObject, "\t", res)
                if "error" in res:
                    error = res['error']
                    saleTrackerObject['error_reason'] = error['message']
                    if 'actual_error' in error:
                        saleTrackerObject['actual_error'] = error['actualError']
                else:
                    saleTrackerObject['error_reason'] = res
                saleTrackerObject['link'] = "Post HTTP : " + link
                saleTrackerObject['execution_timestamp'] = curtime
                self.errorlist.append(saleTrackerObject)
                return r.json()
        else:
            print("ERRORRECORD_Activity HTTP: \t ", link,
                  "\t saleTrackerObject : ", saleTrackerObject, "\t", res)
            saleTrackerObject['link'] = "Post HTTP : " + link
            if "error" in res:
                error = res['error']
                if 'message' in error:
                    saleTrackerObject['error_reason'] = error['message']
                else:
                    saleTrackerObject['error_reason'] = error
                if 'actual_error' in error:
                    saleTrackerObject['actual_error'] = error['actualError']
            saleTrackerObject['execution_timestamp'] = curtime
            self.errorlist.append(saleTrackerObject)

    def getErrorlist(self):
        return self.errorlist
