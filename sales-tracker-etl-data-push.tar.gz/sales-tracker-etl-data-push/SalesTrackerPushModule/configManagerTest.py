import argparse
from SalesTrackerDataPushDriver import SalesTrackerDataPushDriver
import boto3


def main(args):
    aws_access_key_id = args.awsAccessKeyId
    aws_secret_access_key = args.awsSecretAccessKey
    inputConfigFilePath = args.inputConfigFilePath
    inputDataPath = args.inputDataPath
    delimiter = args.delimiter
    print(aws_secret_access_key, aws_access_key_id, inputConfigFilePath)
    session = boto3.Session(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
    )
    job3 = SalesTrackerDataPushDriver(inputConfigFilePath, inputDataPath, aws_access_key_id, aws_secret_access_key,
                                      delimiter)
    job3.processAllObjects()


if __name__ == "__main__":
    """
       Usage Example :: 
       python configManagerTest.py --inputConfigFilePath s3://sales-tracker-aura-dev/config/inputConfig.json --inputDataPath s3://sales-tracker-aura-dev/output/ --delimiter , --awsAccessKeyId AKIA3BOKMALELMEE736G --awsSecretAccessKey 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 
    """
    parser = argparse.ArgumentParser("Utility to Trigger a Processor")
    parser.add_argument("--awsAccessKeyId", type=str, required=True,
                        help="aws_access_key_id")
    parser.add_argument("--awsSecretAccessKey", type=str, required=True,
                        help="aws_secret_access_key")
    parser.add_argument("--inputConfigFilePath", type=str, required=True,
                        help="s3 input config file path")
    parser.add_argument("--inputDataPath", type=str, required=True,
                        help="s3 input Data file path")
    parser.add_argument("--delimiter", type=str, required=True,
                        help="Read file using given delimiter")

    args = parser.parse_args()
    main(args)
