import json
from datetime import datetime

import Constants
from Record import Record
from SalesTrackerConnector import SalesTrackerConnector
import boto3


class SalesTrackerDataPush:
    def __init__(self, configFilePath, inputFilePath, session, delimiter, errorFilePath, commonProps, schemaObject,
                 awsmetric, objectType, execARN,stateFilePath,stateid):
        self.commonProps = commonProps
        self.schemaObject = schemaObject
        self.inputFilePath = inputFilePath
        self.session = session
        self.errorFilePath = errorFilePath
        self.stateFilePath=stateFilePath
        self.recordObj = Record(self.inputFilePath, self.session, delimiter,stateid, errorFilePath,stateFilePath)
        self.salesTrackerConnectorObj = SalesTrackerConnector(self.commonProps)
        self.compulsaryProp = []
        self.token = self.getToken()
        self.tenant_id = self.getTenantIdValue()
        self.errorlist = []
        self.awsmetric = awsmetric
        self.stateid=stateid
        self.objectType = objectType
        self.metricArray = []
        self.execARN = execARN
        self.saleConfigId = ""

    def putErrorObjIntoS3(self, obj):
        print("in putErrorObjIntoS3")
        self.recordObj.writeJsonToS3(obj)

    def getToken(self):
        config = self.commonProps
        outhJson = {"username": config[Constants.KEY_OUTH_USERNAME], "password": config[Constants.KEY_OAUTH_PASSWORD]}
        token = self.salesTrackerConnectorObj.getAuthenticationToken(outhJson)
        return token

    def getTenantIdValue(self):
        config = self.commonProps
        tenantIdValue = config[Constants.KEY_TENANT_ID_VALUE]
        return tenantIdValue

    def getConnectorId(self):
        config = self.commonProps
        connectorIdValue = config[Constants.KEY_CONNECTOR_ID]
        return connectorIdValue

    def getConnectorType(self):
        config = self.commonProps
        connectorTypeValue = config[Constants.KEY_CONNECTOR_TYPE]
        return connectorTypeValue

    def getSaleId(self, dictResult):
        primary_field_id = dictResult[Constants.KEY_PRIMARY_FIELD_ID]
        sale_id = self.salesTrackerConnectorObj.getSales(self.tenant_id, primary_field_id, self.token)
        return sale_id

    def saleDataValidation(self, saleJson, dictResult):
        validation = True
        coreFieldsList = saleJson[Constants.KEY_CORE_FIELDS]

        customFieldsList = saleJson[Constants.KEY_CUSTOM_FIELDS]
        fieldsList = []
        # salesCoreField = Constants.KEY_SALE_CORE_FIELDS
        # salesCoreField = ""
        # print("saleJson[Constants.KEY_METHOD_TYPE] :", saleJson[Constants.KEY_METHOD_TYPE])
        if saleJson[Constants.KEY_METHOD_TYPE] == Constants.KEY_PATCH_METHOD:
            salesCoreField = Constants.KEY_SALE_CORE_FIELDS_PATCH
            # print("sale core field : ", salesCoreField)
        else:
            salesCoreField = Constants.KEY_SALE_CORE_FIELDS
        salesCoreFieldLists = salesCoreField.split(",")
        coreList = []
        for c in coreFieldsList:
            coreList.append(c['schema_field_name'])
        for a in salesCoreFieldLists:
            if a not in coreList:
                print(a + " not present in input json schema")
                validation = False
        if validation == False:
            print(self.objectType,"Expected core fields not present in input json schema")
            print("Expected core fields : ", salesCoreFieldLists)
            print("Json input core filed list: ", coreList)
            return validation

        # check score fields column in input DF
        for i in coreFieldsList:

            inputfieldname = i['input_field_name']
            schemafieldname = i['schema_field_name']
            # print("in core field list for loop",inputfieldname,schemafieldname)
            if inputfieldname not in dictResult or (dictResult[
                                                        inputfieldname] == Constants.KEY_STR_DEFAULT_VALUE and schemafieldname in salesCoreFieldLists) or type(
                dictResult[inputfieldname]) == float:
                # print("in core for loop :", i['input_field_name'], "not in dictresult")
                fieldsList.append(i['input_field_name'])
                validation = False

        # check custom fields column in input DF
        for i in customFieldsList:
            # print("in custom field list for loop",i['input_field_name'])
            if i['input_field_name'] not in dictResult:
                # print("in custom for loop :", i['input_field_name'], "not in dictresult")
                fieldsList.append(i['input_field_name'])
                validation = False

        # check reference data
        reference = saleJson[Constants.KEY_REFERENCE]
        types = reference[Constants.KEY_TYPES]
        typeList = types.split(",")
        schemaArray = reference[Constants.KEY_SCHEMA]
        for schema in schemaArray:
            refType = schema[Constants.KEY_REF_TYPE]
            for j in typeList:
                if j == refType:
                    # print("same :", refType, j)
                    flag = True
                    break
            if flag == False:
                print(self.objectType,"given====== " + refType + " ======not in reference schema list")
                validation = False
                return validation
            ref_fields = schema[Constants.KEY_REF_FIELDS]
            # print("ref fields ",ref_fields)
            for f in ref_fields:
                fields = f[Constants.KEY_FIELDS]
                # print("fields :",fields)
                for i in fields:
                    # print("in ref for loop :",i['input_field_name'])
                    if i['input_field_name'] not in dictResult:
                        # print("in ref for loop :",i['input_field_name'],"not in dictresult")
                        fieldsList.append(i['input_field_name'])
                        validation = False

        print(self.objectType,"Following list of column not present in input records or value is 'Not Available': ", fieldsList)
        return validation

    def activityDataValidation(self, saleJson, dictResult):
        validation = True
        # print(saleJson)
        coreFieldsList = saleJson[Constants.KEY_CORE_FIELDS]
        subLevelFieldsList = saleJson[Constants.KEY_SUBLEVAL_FIELDS]
        customFieldsList = saleJson[Constants.KEY_CUSTOM_FIELDS]
        fieldsList = []
        activityCoreField = Constants.KEY_ACTIVITY_CORE_FIELDS
        activityCoreFieldLists = activityCoreField.split(",")
        coreList = []
        # Validate core fields
        for c in coreFieldsList:
            coreList.append(c['schema_field_name'])
        for a in activityCoreFieldLists:
            if a not in coreList:
                print(a + " not present in input json schema")
                validation = False
        if validation == False:
            print(self.objectType,"Expected core fields not present in input json schema")
            print("Expected core fields : ", activityCoreFieldLists)
            print("Json input core filed list: ", coreList)
            return validation

        # check core fields column in input DF
        for i in coreFieldsList:
            inputfieldname = i['input_field_name']
            schemafieldname = i['schema_field_name']
            if inputfieldname not in dictResult or (dictResult[
                                                        inputfieldname] == Constants.KEY_STR_DEFAULT_VALUE and schemafieldname in activityCoreFieldLists) or type(
                dictResult[inputfieldname]) == float:
                fieldsList.append(i['input_field_name'])
                validation = False

        # check sub level fields column in input DF
        for k in subLevelFieldsList:
            if k['input_field_name'] not in dictResult:
                fieldsList.append(k['input_field_name'])
                validation = False

        # check custom fields column in input DF
        for i in customFieldsList:
            if i['input_field_name'] not in dictResult:
                fieldsList.append(i['input_field_name'])
                validation = False

        # check reference data
        reference = saleJson[Constants.KEY_REFERENCE]
        types = reference[Constants.KEY_TYPES]
        typeList = types.split(",")
        schemaArray = reference[Constants.KEY_SCHEMA]
        for schema in schemaArray:
            refType = schema[Constants.KEY_REF_TYPE]
            for j in typeList:
                if j == refType:
                    # print("same :", refType, j)
                    flag = True
                    break
            if flag == False:
                print(self.objectType,"given====== " + refType + " ======not in reference schema list")
                validation = False
                return validation
            ref_fields = schema[Constants.KEY_REF_FIELDS]
            for f in ref_fields:
                fields = f[Constants.KEY_FIELDS]
                for i in fields:
                    if i['input_field_name'] not in dictResult:
                        fieldsList.append(i['input_field_name'])
                        validation = False
        # print("start segment validation")
        if Constants.KEY_SEGMENTS in saleJson:
            segments = saleJson[Constants.KEY_SEGMENTS]
            segFields = segments[Constants.KEY_SEG_FIELDS]
            # print("in validation : segments ", segments, "  segFields :", segFields)
            for f in segFields:
                fields = f[Constants.KEY_FIELDS]
                # print("fields :", fields)
                for i in fields:
                    # print("in validation i ", i['input_field_name'])
                    if i['input_field_name'] not in dictResult:
                        # print(" is not available in resultdict")
                        fieldsList.append(i['input_field_name'])
                        validation = False

        print(self.objectType,"Following list of column not present in input records or value is 'Not Available': ", fieldsList)
        return validation

    def createActivityAPIInputJson(self, saleJson, dictResult, sale_id, saleConfigId):
        # print(saleJson)
        coreFieldsList = saleJson[Constants.KEY_CORE_FIELDS]
        subLevelFieldsList = saleJson[Constants.KEY_SUBLEVAL_FIELDS]
        customFieldsList = saleJson[Constants.KEY_CUSTOM_FIELDS]
        coreFieldDict = {}
        for i in coreFieldsList:
            coreFieldDict[i['schema_field_name']] = i['input_field_name']
        # print(coreFieldDict)
        customFieldDict = {}
        for j in customFieldsList:
            val1 = ""
            val2 = j['schema_field_name']
            if dictResult[j['input_field_name']] != Constants.KEY_STR_DEFAULT_VALUE:
                if 'data_type' in j:
                    if j['data_type'] == "int":
                        val1 = int(float(dictResult[j['input_field_name']]))
                        # customFieldDict[j['schema_field_name']] = int(dictResult[j['input_field_name']])
                else:
                    val1 = dictResult[j['input_field_name']]
                    # customFieldDict[j['schema_field_name']] = dictResult[j['input_field_name']]
            # print("val = ", val, " val2 :", val2)
            schemaPath = j[Constants.KEY_SCHEMA_FIELD_PATH]
            schemaPathList = []
            # if schemaPath != "":
            schemaPathList = schemaPath.split(".")

            # print("schemaPathList", schemaPathList)
            # keys = groupingDict.keys()
            if val1 != "" and val1 != 'not available':
                self.add_elem(customFieldDict, schemaPathList, val1, val2)
            # elif val != ""  and schemaPathList == []:
            #     customFieldDict[val2]=val
        print("customFieldDict : ", customFieldDict)
            # if dictResult[j['input_field_name']] != Constants.KEY_STR_DEFAULT_VALUE and dictResult[
            #     j['input_field_name']]:
            #     if 'data_type' in j:
            #         if j['data_type'] == "int":
            #             customFieldDict[j['schema_field_name']] = int(dictResult[j['input_field_name']])
            #     else:
            #         customFieldDict[j['schema_field_name']] = dictResult[j['input_field_name']]


        subLevelFieldDict = {}
        for k in subLevelFieldsList:
            subLevelFieldDict[k['schema_field_name']] = dictResult[k['input_field_name']]

        params1 = {"activityTs": dictResult[coreFieldDict['activityTs']],
                   "agentId": dictResult[coreFieldDict['agentId']]}
        if sale_id == "":
            sale_id = dictResult[coreFieldDict['activityId']]
        source = {"activityId": sale_id,
                  "sourcePath": "S3",
                  "createdBy": dictResult[coreFieldDict['createdBy']],
                  "createdOn": dictResult[coreFieldDict['createdOn']]}
        # customProperties = {"activityData": customFieldDict}
        customProperties = customFieldDict

        reference = saleJson[Constants.KEY_REFERENCE]
        types = reference[Constants.KEY_TYPES]

        schemaArray = reference[Constants.KEY_SCHEMA]
        referenceDict = {}
        for schema in schemaArray:
            refType = schema[Constants.KEY_REF_TYPE]
            ref_fields = schema[Constants.KEY_REF_FIELDS]
            fieldArray = []
            for f in ref_fields:
                fields = f[Constants.KEY_FIELDS]
                fieldDict = {}
                flagVal = True
                for i in fields:
                    # print("i from fields : ", i, dictResult[i[Constants.KEY_INPUT_FIELD_NAME]])
                    if dictResult[i[Constants.KEY_INPUT_FIELD_NAME]] != Constants.KEY_STR_DEFAULT_VALUE:
                        fieldDict[i[Constants.KEY_SCHEMA_FIELD_NAME]] = dictResult[i[Constants.KEY_INPUT_FIELD_NAME]]
                    else:
                        flagVal = False
                        break
                if fieldDict != {} and flagVal != False:
                    fieldArray.append(fieldDict)
            if refType == Constants.KEY_REF_ACCOUNT:
                referenceDict = {"account": fieldArray}
            elif refType == Constants.KEY_REF_CONTACT:
                referenceDict = {"contact": fieldArray}
            elif refType == Constants.KEY_REF_STAGE:
                referenceDict = {"stage": fieldArray}
        print("ref dict :", referenceDict)

        if Constants.KEY_REF_ACCOUNT not in referenceDict.keys():
            referenceDict["account"] = []
        if Constants.KEY_REF_CONTACT not in referenceDict.keys():
            referenceDict["contact"] = []
        if Constants.KEY_REF_STAGE not in referenceDict.keys():
            referenceDict["stage"] = []
        print("final ref dict :", referenceDict)

        segfieldArray = []
        if Constants.KEY_SEGMENTS in saleJson:
            segments = saleJson[Constants.KEY_SEGMENTS]
            segFields = segments[Constants.KEY_SEG_FIELDS]
            for segField in segFields:
                fields = segField[Constants.KEY_FIELDS]
                # print("seg fields : ", fields)
                fieldDict = {}
                segflagVal = True
                for i in fields:
                    # print("i[Constants.KEY_INPUT_FIELD_NAME] :", i[Constants.KEY_INPUT_FIELD_NAME],
                    #       "  dictResult[i[Constants.KEY_INPUT_FIELD_NAME]]   :",
                    #       dictResult[i[Constants.KEY_INPUT_FIELD_NAME]])
                    if dictResult[i[Constants.KEY_INPUT_FIELD_NAME]] != Constants.KEY_STR_DEFAULT_VALUE:
                        fieldDict[i[Constants.KEY_SCHEMA_FIELD_NAME]] = dictResult[i[Constants.KEY_INPUT_FIELD_NAME]]
                    else:
                        segflagVal = False
                        break
                if fieldDict != {} and segflagVal != False:
                    segfieldArray.append(fieldDict)

        print("final segment array : ", segfieldArray)
        payLoad = {}
        if saleJson['activity_type'].lower() == "email":
            email = subLevelFieldDict
            email['customProperties'] = customProperties
            payLoad["email"] = email
        if saleJson['activity_type'].lower() == "call":
            call = subLevelFieldDict
            call['customProperties'] = customProperties
            call['segment'] = segfieldArray
            payLoad["call"] = call
        if saleJson['activity_type'].lower() == "sms":
            sms = subLevelFieldDict
            sms['customProperties'] = customProperties
            payLoad["sms"] = sms

        if saleJson['activity_type'].lower() == "custom":
            payLoad["custom"] = customProperties
        params1["references"] = referenceDict
        params1["payload"] = payLoad
        params1["source"] = source
        return params1

    def add_elem(self,jsondict, keys, val1, val2):
        parent = jsondict
        for k in keys:
            if k not in parent:
                parent[k] = {}
            parent = parent[k]
        # print("-1 key ",keys[-1])
        parent[val2] = val1
        # print("parent[val2] ",parent[val2])
        # return parent

    def createSalesTrackerAPIInputJson(self, saleJson, dictResult, sale_id, saleConfigId):
        # print(saleJson)
        coreFieldsList = saleJson[Constants.KEY_CORE_FIELDS]
        customFieldsList = saleJson[Constants.KEY_CUSTOM_FIELDS]
        coreFieldDict = {}
        for i in coreFieldsList:
            coreFieldDict[i['schema_field_name']] = i['input_field_name']
        customFieldDict = {}
        groupingDict={}
        for j in customFieldsList:
            val1 = ""
            val2 =j['schema_field_name']
            if dictResult[j['input_field_name']] != Constants.KEY_STR_DEFAULT_VALUE:
                if 'data_type' in j:
                    if j['data_type'] == "int":
                        val1 = int(float(dictResult[j['input_field_name']]))
                        # customFieldDict[j['schema_field_name']] = int(dictResult[j['input_field_name']])
                else:
                    val1=dictResult[j['input_field_name']]
                    # customFieldDict[j['schema_field_name']] = dictResult[j['input_field_name']]
            # print("val = ",val," val2 :",val2)
            schemaPath=j[Constants.KEY_SCHEMA_FIELD_PATH]
            schemaPathList = []
            # if schemaPath != "":
            schemaPathList=schemaPath.split(".")

            # print("schemaPathList",schemaPathList)
            # keys = groupingDict.keys()
            # print("val :",val1)
            if val1 != "" and val1 != 'not available':
                self.add_elem(customFieldDict,schemaPathList,val1,val2)
            # elif val != ""  and schemaPathList == []:
            #     customFieldDict[val2]=val
        print("customFieldDict : ",customFieldDict)
            # p=""
            # groupingDict[]
            # for path in schemaPathList:
            #     groupingDict['sss']['ddd']['s]']

                # if path not in keys:
                #     groupingDict[path]={}

            # str1=""
            # for path in schemaPathList:
            #     str1=str1+"["+path+"]"
            #
            # # str1="customFieldDict"+str1+"[j['schema_field_name']]"
            # print("str1 :",str1)
            # customFieldDict[j['schema_field_name']] = dictResult[j['input_field_name']]
            # if dictResult[j['input_field_name']] != Constants.KEY_STR_DEFAULT_VALUE:
            #     if 'data_type' in j:
            #         if j['data_type'] == "int":
            #             customFieldDict[j['schema_field_name']] = int(dictResult[j['input_field_name']])
            #     else:
            #         customFieldDict[j['schema_field_name']] = dictResult[j['input_field_name']]

        reference = saleJson[Constants.KEY_REFERENCE]
        types = reference[Constants.KEY_TYPES]
        schemaArray = reference[Constants.KEY_SCHEMA]
        referenceDict = {}
        for schema in schemaArray:
            refType = schema[Constants.KEY_REF_TYPE]
            ref_fields = schema[Constants.KEY_REF_FIELDS]
            fieldArray = []
            for f in ref_fields:
                fields = f[Constants.KEY_FIELDS]
                fieldDict = {}
                flagVal = True
                for i in fields:
                    # print("i from fields : ", i, dictResult[i[Constants.KEY_INPUT_FIELD_NAME]])
                    if dictResult[i[Constants.KEY_INPUT_FIELD_NAME]] != Constants.KEY_STR_DEFAULT_VALUE:
                        fieldDict[i[Constants.KEY_SCHEMA_FIELD_NAME]] = dictResult[i[Constants.KEY_INPUT_FIELD_NAME]]
                    else:
                        flagVal = False
                        break
                if fieldDict != {} and flagVal != False:
                    fieldArray.append(fieldDict)
            if refType == Constants.KEY_REF_ACCOUNT:
                referenceDict['account'] = fieldArray
            elif refType == Constants.KEY_REF_CONTACT:
                referenceDict['contact'] = fieldArray
            elif refType == Constants.KEY_REF_STAGE:
                referenceDict['stage']= fieldArray
        if Constants.KEY_REF_ACCOUNT not in referenceDict.keys():
            referenceDict["account"] = []
        if Constants.KEY_REF_CONTACT not in referenceDict.keys():
            referenceDict["contact"] = []
        if Constants.KEY_REF_STAGE not in referenceDict.keys():
            referenceDict["stage"] = []
        print("final ref dict :", referenceDict)
        methodType = saleJson[Constants.KEY_METHOD_TYPE]
        if methodType == Constants.KEY_PATCH_METHOD:
            params1 = {"saleConfigId": saleConfigId,
                       "agentId": dictResult[coreFieldDict['agentId']]}
        else:
            params1 = {"stageId": dictResult[coreFieldDict['stageId']],
                       "saleConfigId": saleConfigId,
                       "status": dictResult[coreFieldDict['status']],
                       "agentId": dictResult[coreFieldDict['agentId']]}

        # customProperties = {"saleData": customFieldDict}
        payLoad = {"customProperties": customFieldDict}
        params1["payLoad"] = payLoad

        if sale_id == "":
            sale_id = dictResult[coreFieldDict['saleId']]
        source = {"externalSaleId": sale_id,
                  "sourcePath": "S3",
                  "createdBy": dictResult[coreFieldDict['createdBy']],
                  "createdTs": dictResult[coreFieldDict['createdTs']]}
        params1["source"] = source
        params1["references"] = referenceDict
        return params1

    def getDimesionDict(self, tenantid, objecttype, connectortype, connectorid, moduletype):
        dict = {}
        dict['tenantid'] = tenantid
        dict['objectType'] = objecttype
        dict['moduleType'] = moduletype
        dict['connectorId'] = connectorid
        dict['connectorType'] = connectortype
        return dict

    def writeStateFile(self):
        finalSateId = self.recordObj.getRecordCount()
        print("finalSateId : ",finalSateId)
        stateJson = {'id': finalSateId}
        print("state json : " , str(stateJson))
        self.recordObj.writeJsonToS3(stateJson, self.stateFilePath)

    def processSalesObjectData(self):

        dictResult = self.recordObj.nextRecord()
        timestampVal = datetime.utcnow()
        connectorId = self.execARN
        connectorType = self.getConnectorType()
        dict = self.getDimesionDict(self.tenant_id[:-1], self.objectType, connectorType, connectorId, "DataPushLayer")
        totalCount = self.recordObj.getTotalCount()

        putTotalJson = self.awsmetric.preparePutMetricsDataParameters(dict, "TotalRecordCount", totalCount,
                                                                      timestampVal, "Count")
        self.metricArray.append(putTotalJson)
        # print(self.metricArray)
        # print("dictResult :",dictResult)
        while (dictResult != None):
            curtime = datetime.now().strftime("%d-%b-%Y %H:%M:%S")
            print(dictResult)
            stage_id = dictResult[Constants.KEY_STAGE_ID]
            if stage_id == 'Activity':
                validation = self.activityDataValidation(self.schemaObject, dictResult)
            else:
                validation = self.saleDataValidation(self.schemaObject, dictResult)
            if validation == False:
                dictResult['error_reason'] = "Validation failed"
                dictResult['execution_timestamp'] = curtime
                self.errorlist.append(dictResult)
                dictResult = self.recordObj.nextRecord()
                print("validation failed")
                continue
            print("validation successfull")
            # saleConfigId = "937647ae-c040-4212-a044-3b78977bc894"
            if self.saleConfigId == "":
                self.saleConfigId = self.salesTrackerConnectorObj.getSaleConfigId(self.tenant_id, self.token)
                if self.saleConfigId == "Retry Failed":
                    self.writeStateFile()
                    raise Exception("retry failed")


            print("saleConfigId :", self.saleConfigId)
            if stage_id != 'Activity':
                saleTrackerObject = self.createSalesTrackerAPIInputJson(self.schemaObject, dictResult, "",
                                                                        self.saleConfigId)
                parm = json.loads(json.dumps(saleTrackerObject))
                print("param ", stage_id, parm)
                if self.schemaObject[Constants.KEY_METHOD_TYPE].lower() == Constants.KEY_POST_METHOD:
                    sale_id = self.salesTrackerConnectorObj.postSaleObject(self.tenant_id, parm, self.token)
                elif self.schemaObject[Constants.KEY_METHOD_TYPE].lower() == Constants.KEY_PATCH_METHOD:
                    sale_id = self.salesTrackerConnectorObj.patchSaleObject(self.tenant_id, saleTrackerObject,
                                                                            self.token, stage_id)
                if sale_id == "Retry Failed":
                    self.writeStateFile()
                    raise Exception("retry failed")
            elif stage_id == "Activity":
                saleTrackerObject = self.createActivityAPIInputJson(self.schemaObject, dictResult, "",
                                                                    self.saleConfigId)
                parm = json.loads(json.dumps(saleTrackerObject))
                print("activity param ", parm)
                sale_id = parm['source']['activityId']

                ob = self.salesTrackerConnectorObj.postActivityObject(self.tenant_id, sale_id, parm,
                                                                      self.schemaObject['activity_link_endpoint'],
                                                                      self.token, self.saleConfigId)
                if ob == "Retry Failed":
                    self.writeStateFile()
                    raise Exception("retry failed")

            dictResult = self.recordObj.nextRecord()
        jsonObj = self.salesTrackerConnectorObj.getErrorlist()
        jsonObj = jsonObj + self.errorlist
        if jsonObj != []:
            errorcount = len(jsonObj)
            successCount = totalCount - errorcount
            timestampVal = datetime.utcnow()
            putErrorJson = self.awsmetric.preparePutMetricsDataParameters(dict, "ErrorRecordCount", errorcount,
                                                                          timestampVal, "Count")
            self.metricArray.append(putErrorJson)
            # print(self.metricArray)
            putSuccessJson = self.awsmetric.preparePutMetricsDataParameters(dict, "SuccessRecordCount", successCount,
                                                                            timestampVal, "Count")

            self.metricArray.append(putSuccessJson)

            self.recordObj.writeJsonToS3(jsonObj,self.errorFilePath)
        else:
            timestampVal = datetime.utcnow()
            errorcount = 0
            putErrorJson = self.awsmetric.preparePutMetricsDataParameters(dict, "ErrorRecordCount", errorcount,
                                                                          timestampVal, "Count")
            self.metricArray.append(putErrorJson)
            putSuccessJson = self.awsmetric.preparePutMetricsDataParameters(dict, "SuccessRecordCount", totalCount,
                                                                            timestampVal, "Count")
            self.metricArray.append(putSuccessJson)
        print("final metrics data :", self.metricArray)
        self.awsmetric.putMetricsDataCall(self.tenant_id[:-1], self.metricArray)
        # self.putMetricsDataCall(self.tenant_id[:-1])

        #write respected object state id into respected object statefile path
        self.writeStateFile()

        # finalSateId = self.recordObj.getRecordCount()
        # stateJson = {'id': finalSateId}
        # self.recordObj.writeJsonToS3(stateJson, self.stateFilePath)
