import datetime

# from .dependency import boto3


class AWSMetrics():
    def __init__(self, servicename, session):
        self.client = session.client(servicename)

    def prepareGetMetricsDataParameter(self, dict, namespace, id, idmetric, metricname,period,stat,unit):
        idjson = {'Id': id, 'Expression': idmetric, 'Label': metricname}
        dimentions = self.createDimention(dict)
        print("in metric layer",dimentions)

        metric = {'Namespace': namespace, 'MetricName': metricname, 'Dimensions': dimentions}
        metricstat = {'Metric': metric, 'Period': period, 'Stat': stat, 'Unit': unit}
        idmetricjson = {'Id': idmetric, 'MetricStat': metricstat, 'ReturnData': False}
        metricdataqueries = [idjson, idmetricjson]
        return metricdataqueries

    def createDimention(self, dict):
        dimentions = []
        for i in dict:
            dimention = {}
            dimention['Name'] = i
            dimention['Value'] = dict[i]
            dimentions.append(dimention)
        return dimentions


    def getMetricCall(self, metricdataqueries,starttime,endtime):
        # starttime=datetime.datetime(1994, 2, 9, 0, 0, 0, 0)
        # endtime=datetime.datetime.utcnow()
        print(starttime,endtime)
        response1 = self.client.get_metric_data(MetricDataQueries=metricdataqueries,
                                                StartTime=starttime,
                                                EndTime=endtime)
        return response1

    def preparePutMetricsDataParameters(self, dict,matricName, count, timestamp, unit):
        dimentions = self.createDimention(dict)

        metricDataJson = {'MetricName': matricName, 'Dimensions': dimentions, 'Timestamp': timestamp, 'Unit':unit,
                          'Value': count}
        return metricDataJson


    def putMetricsDataCall(self, namespace, metricArray):
        response = self.client.put_metric_data(MetricData=metricArray, Namespace=namespace)
        return response
